export const MenuItems = [
  {
    id: 1,
    name: "Greek Salad",
    img: "greek_salad.jpg",
    price: "$12.99",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  },
  {
    id: 2,
    name: "Bruschetta",
    img: "bruchetta.jpg",
    price: "$5.99",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  },
  {
    id: 3,
    name: "Lemon Desert",
    img: "lemon_dessert.jpg",
    price: "$5.00",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  }
];
