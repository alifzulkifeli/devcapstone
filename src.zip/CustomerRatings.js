export const CustomerRatings = [
  {
    id: 1,
    name: "Tilly",
    img: "Tilly.png",
    rating: "5",
    feedback: "Best Mideteranain restaurant"
  },
  {
    id: 2,
    name: "Derek",
    img: "customer.jpg",
    rating: "4",
    feedback: "Best Greek Salad"
  },
  {
    id: 3,
    name: "Bob",
    img: "Bob.jpg",
    rating: "2",
    feedback: "Very Ok Restaurant"
  }
];
