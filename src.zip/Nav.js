import { Link } from "react-router-dom";

function Nav() {
  return (
    <nav>
      <ul className="grid-inline-nav">
        <li>
          <Link to="./">
            <img
              src="assets/logo2.png"
              alt="Little Lemon logo"
              width="50px"
              height="60px"
            />
          </Link>
        </li>
        <li>
          <Link to="./">Home</Link>
        </li>
        <li>
          <Link to="./about">About</Link>
        </li>
        <li>
          <Link to="./">Menu</Link>
        </li>
        <li>
          <Link to="./reservations">Reservations</Link>
        </li>
        <li>
          <Link to="./">Order Online</Link>
        </li>
        <li>
          <Link to="./">Login</Link>
        </li>
      </ul>
    </nav>
  );
}

export default Nav;
